Red Ink Browser Extension Package
=================================

Copyright by David Rosenthal, VISCHER
david.rosenthal@vischer.com

Website: https://vischer.com/redink
Sources: https://github.com/VISCHER-LIL/redink

The extension is currently being tested. It is available either through the Microsoft and Google extension store or you can install it manually: 

1. Copy the content of the ZIP file to a directory where you wish to host the browser extension files. 
2. In your browser (Chrome, Edge, Firefox), enter, for example: edge://extensions/
3. Ensure that the window is wide enough. On the left side you see "Developer Mode". Turn it on. 
4. Choose "Load unpacked"
5. Select the directory where you have stored the content of the ZIP file
6. You can again turn off the developer mode

February 8, 2025



