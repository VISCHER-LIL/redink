Red Ink Testing Set
===================

This ZIP archive contains a curated set of test materials for evaluating the AI tool "Red Ink". You can use them to test the various features of Red Ink without using confidential, proprietary documents of your own. Also, the package contains an Excel worksheet that provides for a series of test cases cases including the possibility to document the result for the model you use (we have included a sample for Google Gemini 2.5 Pro). 

Red Ink Testing Files
---------------------

Edge (incl. Local Chatbot) 
Excel 
Word
Outlook

... each contain sample files for testing the features of the add-ins/extension

Libraries
---------

Contains a number of library files that Red Ink uses for various features (e.g., Doc Check, Find Clause)



Want to better understand this? Check out the demo-videos on https://redink.ai, which show these files in "action", and study the manual, also available on https://redink.ai.
